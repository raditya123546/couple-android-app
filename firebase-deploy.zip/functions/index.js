/**
 * Cloud Function: kirim push FCM ke pasangan saat ada "signal" baru.
 * Deploy pakai: firebase deploy --only functions
 */
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const messaging = getMessaging();

// Trigger: couples/{coupleCode}/signals/{signalId} baru dibuat
exports.onKangen = onDocumentCreated("couples/{coupleCode}/signals/{signalId}", async (event) => {
  const snap = event.data;
  if (!snap) return;
  const data = snap.data();
  const { coupleCode } = event.params;
  const fromId = data.fromId;

  // Ambil semua token di couple ini, kecuali pengirim
  const tokenDocs = await db.collection("couples").doc(coupleCode).collection("tokens").get();
  const tokens = [];
  tokenDocs.forEach(d => {
    if (d.id !== fromId) {
      const t = d.data().fcmToken;
      if (t) tokens.push(t);
    }
  });

  if (tokens.length === 0) {
    console.log("Tidak ada token pasangan untuk", coupleCode);
    return;
  }

  const msg = {
    notification: {
      title: data.title || "💖 Kangen!",
      body: data.body || "Pasangan lo lagi kangen!"
    },
    data: { type: data.type || "kangen" },
    tokens
  };

  try {
    const res = await messaging.sendEach(msg);
    console.log("Push terkirim:", res.successCount);
  } catch (e) {
    console.error(e);
  }
});
