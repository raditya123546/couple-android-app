package com.couplekangen.app;

import android.app.Activity;
import android.os.Bundle;

// Dibuka saat klik notif push Firebase (deep link fallback)
public class NotifyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish();
    }
}
