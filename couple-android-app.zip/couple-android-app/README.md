# Couple Kangen — Android APK

WebView wrapper buat PWA **Couple Kangen**:
`https://fantastic-biscuit-401732.netlify.app`

## Build APK (GitHub Actions — paling gampang)
1. Upload folder `couple-android-app/` ini ke GitHub repo baru
2. Di repo itu: **Settings > Secrets and variables > Actions**
   - Tambah secret `KEYSTORE_PASSWORD` (random password, misal `couple12345`)
   - Tambah secret `KEY_PASSWORD` (samain aja)
3. Commit & push — workflow `Build APK` jalan otomatis
4. Di GitHub repo: **Actions > Build APK > couple-kangen-apk** (artifacts)
   - Download `app-release.apk` — install di POCO lo

## Build manual (kalau punya laptop)
```
cd couple-android-app
gradle assembleRelease
```
APK ada di `app/build/outputs/apk/release/app-release.apk`

## Info
- package: `com.couplekangen.app`
- target SDK 34, min SDK 26
- Butuh notif izin `POST_NOTIFICATIONS` (Android 13+)
- Sudah ada deep link buat URL Netlify-nya
- Firebase config tetap di web (`couple-app-real/firebase-config.js`)
